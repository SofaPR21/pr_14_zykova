package com.example.pr_14

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class EditTaskActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_task)
    }
}